// ===== SERVICE WORKER - PWA Offline Support =====
const CACHE_NAME = 'smart-wallet-v1.2';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/css/style.css',
  '/js/config.js',
  '/js/alchemy.js',
  '/js/wallet.js',
  '/js/contract.js',
  '/js/transactions.js',
  '/js/swap.js',
  '/js/ui.js',
  '/js/app.js',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
];

const EXTERNAL_CACHE = [
  'https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;700;800&display=swap',
  'https://cdn.ethers.io/lib/ethers-5.7.umd.min.js',
];

// Install
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      await cache.addAll(STATIC_ASSETS);
      // Cache external assets separately (may fail on first load)
      for (const url of EXTERNAL_CACHE) {
        try { await cache.add(url); } catch {}
      }
    })
  );
  self.skipWaiting();
});

// Activate - limpa caches antigos
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Fetch - Stale-while-revalidate para assets estáticos, network-first para APIs
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // APIs Alchemy/RPC: sempre network (sem cache)
  if (url.hostname.includes('alchemy.com') ||
      url.hostname.includes('binance.org') ||
      url.hostname.includes('avax.network') ||
      url.pathname.includes('/v2/') ||
      request.method !== 'GET') {
    return; // deixa o browser lidar (sem cache)
  }

  // Assets estáticos: cache-first
  event.respondWith(
    caches.match(request).then(cached => {
      const networkFetch = fetch(request).then(response => {
        if (response && response.status === 200) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(request, clone));
        }
        return response;
      }).catch(() => cached);

      return cached || networkFetch;
    })
  );
});
