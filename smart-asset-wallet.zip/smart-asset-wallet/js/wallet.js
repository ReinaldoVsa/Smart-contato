// ===== WALLET.JS - Conexão de Carteira (WalletConnect v2 + Manual) =====

async function connectWalletConnect() {
  const { settings } = window.AppState;
  const projectId = settings.walletConnectProjectId;

  if (!projectId) {
    showToast('Configure seu WalletConnect Project ID nas Configurações primeiro!', 'error');
    showScreen('settingsScreen');
    return;
  }

  showToast('Iniciando WalletConnect...', 'info');

  try {
    // Carrega WalletConnect v2 dinamicamente
    const wcScript = document.createElement('script');
    wcScript.src = 'https://cdn.jsdelivr.net/npm/@walletconnect/ethereum-provider@2.17.0/dist/index.umd.js';
    document.head.appendChild(wcScript);

    await new Promise((res, rej) => {
      wcScript.onload = res;
      wcScript.onerror = () => rej(new Error('Falha ao carregar WalletConnect SDK'));
    });

    const chainId = parseInt(settings.defaultNetwork) || 1;
    const WCProvider = window.EthereumProvider;

    const provider = await WCProvider.init({
      projectId,
      chains: [chainId],
      optionalChains: [1, 137, 56, 42161, 10, 8453, 43114],
      showQrModal: true,
      metadata: {
        name: 'Smart Asset Wallet',
        description: 'Saque, transferência e troca de ativos blockchain',
        url: window.location.origin,
        icons: [`${window.location.origin}/icons/icon-192.png`],
      },
    });

    await provider.enable();

    const ethersProvider = new ethers.providers.Web3Provider(provider);
    const signer = ethersProvider.getSigner();
    const address = await signer.getAddress();
    const network = await ethersProvider.getNetwork();

    window.AppState.walletConnectInstance = provider;
    await onWalletConnected(address, network.chainId, ethersProvider, signer);

    // Eventos WalletConnect
    provider.on('accountsChanged', async (accounts) => {
      if (accounts.length === 0) { disconnectWallet(); return; }
      const newAddr = ethers.utils.getAddress(accounts[0]);
      window.AppState.walletAddress = newAddr;
      await refreshBalances();
      showToast('Conta alterada', 'info');
    });

    provider.on('chainChanged', async (newChainId) => {
      const cid = parseInt(newChainId, 16);
      window.AppState.chainId = cid;
      window.AppState.network = NETWORKS[cid] || { name: `Chain ${cid}`, symbol: 'ETH' };
      const newProvider = new ethers.providers.Web3Provider(provider);
      window.AppState.provider = newProvider;
      window.AppState.signer = newProvider.getSigner();
      updateNetworkBadge();
      await refreshBalances();
      showToast(`Rede alterada para ${window.AppState.network.name}`, 'info');
    });

    provider.on('disconnect', () => { disconnectWallet(); });

  } catch (e) {
    console.error('WalletConnect error:', e);
    showToast('Erro ao conectar: ' + (e.message || 'Tente novamente'), 'error');
  }
}

async function connectManual(address, chainId, contractAddress) {
  if (!ethers.utils.isAddress(address)) {
    showToast('Endereço de carteira inválido', 'error');
    return;
  }

  showToast('Conectando...', 'info');

  try {
    const provider = createProvider(chainId);
    // Modo somente leitura (sem signer)
    window.AppState.signer = null;

    await onWalletConnected(address, chainId, provider, null);

    if (contractAddress && ethers.utils.isAddress(contractAddress)) {
      document.getElementById('contractAddress').value = contractAddress;
      await loadContract(contractAddress);
    }

    showToast('Conectado em modo leitura. Use WalletConnect para assinar transações.', 'warn');
  } catch (e) {
    console.error('Manual connect error:', e);
    showToast('Erro: ' + e.message, 'error');
  }
}

async function onWalletConnected(address, chainId, provider, signer) {
  const network = NETWORKS[chainId] || { name: `Chain ${chainId}`, symbol: 'ETH' };

  window.AppState.walletAddress = address;
  window.AppState.chainId = chainId;
  window.AppState.network = network;
  window.AppState.provider = provider;
  window.AppState.signer = signer;
  window.AppState.connected = true;

  saveWalletState({ address, chainId });

  // UI Updates
  const short = `${address.slice(0,6)}...${address.slice(-4)}`;
  document.getElementById('walletAddressDisplay').textContent = short;
  document.getElementById('cardNetwork').textContent = network.name;
  updateNetworkBadge();

  // Load balances
  await refreshBalances();

  // Load history
  loadHistoryFromStorage();

  showScreen('dashboardScreen');
  showToast(`Conectado! ${short}`, 'success');
}

async function refreshBalances() {
  const { walletAddress, provider, network, chainId } = window.AppState;
  if (!walletAddress || !provider) return;

  try {
    const native = await fetchNativeBalance(walletAddress, provider);
    document.getElementById('nativeBalance').textContent = parseFloat(native).toFixed(6);
    document.getElementById('nativeSymbol').textContent = network?.symbol || 'ETH';

    // Token balance (se contrato carregado)
    if (window.AppState.currentTokenInfo) {
      const tb = await fetchTokenBalance(window.AppState.currentTokenInfo.address, walletAddress, provider);
      document.getElementById('tokenBalance').textContent = parseFloat(tb).toFixed(4);
      document.getElementById('tokenSymbol').textContent = window.AppState.currentTokenInfo.symbol;
    }
  } catch (e) {
    console.error('refreshBalances error:', e);
  }
}

function disconnectWallet() {
  if (window.AppState.walletConnectInstance) {
    try { window.AppState.walletConnectInstance.disconnect(); } catch {}
    window.AppState.walletConnectInstance = null;
  }
  window.AppState.walletAddress = null;
  window.AppState.provider = null;
  window.AppState.signer = null;
  window.AppState.connected = false;
  window.AppState.currentTokenInfo = null;
  window.AppState.currentContract = null;
  localStorage.removeItem(STORAGE_KEYS.WALLET);

  document.getElementById('networkName').textContent = 'Desconectado';
  document.getElementById('netDot') && (document.querySelector('.net-dot').style.background = '#666');
  showScreen('connectScreen');
  showToast('Desconectado', 'info');
}

function updateNetworkBadge() {
  const { network } = window.AppState;
  document.getElementById('networkName').textContent = network?.name || 'Desconectado';
}

async function requireSigner() {
  if (!window.AppState.signer) {
    showToast('Conecte via WalletConnect para assinar transações', 'error');
    throw new Error('Signer not available');
  }
  return window.AppState.signer;
}
