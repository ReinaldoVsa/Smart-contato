// ===== ALCHEMY.JS - Integração Alchemy =====

function getAlchemyRpcUrl(chainId, apiKey) {
  const net = NETWORKS[chainId];
  if (!net) return null;
  if (net.publicRpc) return net.publicRpc; // Chains sem suporte Alchemy usam RPC público
  if (!apiKey && net.alchemyPrefix) {
    // Fallback: URL pública de leitura sem key (limitada)
    return `https://${net.alchemyPrefix}.g.alchemy.com/v2/demo`;
  }
  if (apiKey && net.alchemyPrefix) {
    return `https://${net.alchemyPrefix}.g.alchemy.com/v2/${apiKey}`;
  }
  return null;
}

function createProvider(chainId, customRpc, apiKey) {
  const { settings } = window.AppState;
  let rpcUrl = customRpc || settings.customRpc;
  if (!rpcUrl) rpcUrl = getAlchemyRpcUrl(chainId, apiKey || settings.alchemyApiKey);
  if (!rpcUrl) throw new Error(`Rede ${chainId} não suportada`);
  return new ethers.providers.JsonRpcProvider(rpcUrl, chainId);
}

async function fetchNativeBalance(address, provider) {
  try {
    const balance = await provider.getBalance(address);
    return ethers.utils.formatEther(balance);
  } catch (e) {
    console.error('fetchNativeBalance error:', e);
    return '0.0';
  }
}

async function fetchTokenBalance(tokenAddress, walletAddress, provider) {
  try {
    const contract = new ethers.Contract(tokenAddress, ERC20_ABI, provider);
    const [balance, decimals] = await Promise.all([
      contract.balanceOf(walletAddress),
      contract.decimals()
    ]);
    return ethers.utils.formatUnits(balance, decimals);
  } catch (e) {
    console.error('fetchTokenBalance error:', e);
    return '0.0';
  }
}

async function fetchTokenInfo(tokenAddress, walletAddress, provider) {
  try {
    const contract = new ethers.Contract(tokenAddress, ERC20_ABI, provider);
    const [name, symbol, decimals, balance] = await Promise.all([
      contract.name().catch(() => 'Token'),
      contract.symbol().catch(() => '???'),
      contract.decimals().catch(() => 18),
      walletAddress ? contract.balanceOf(walletAddress).catch(() => ethers.BigNumber.from(0)) : Promise.resolve(ethers.BigNumber.from(0)),
    ]);
    const formattedBalance = ethers.utils.formatUnits(balance, decimals);
    return { name, symbol, decimals, balance: formattedBalance, address: tokenAddress, contract };
  } catch (e) {
    console.error('fetchTokenInfo error:', e);
    throw new Error('Não foi possível carregar o token: ' + e.message);
  }
}

async function estimateGas(txParams, provider) {
  try {
    const gasLimit = await provider.estimateGas(txParams);
    const gasPrice = await provider.getGasPrice();
    const { settings } = window.AppState;
    const multiplier = parseFloat(settings.gasPriceMultiplier) || 1.2;
    const adjustedGasPrice = gasPrice.mul(Math.floor(multiplier * 100)).div(100);
    const gasCost = gasLimit.mul(adjustedGasPrice);
    const gasCostEth = ethers.utils.formatEther(gasCost);
    return {
      gasLimit: gasLimit.toString(),
      gasPrice: ethers.utils.formatUnits(adjustedGasPrice, 'gwei'),
      gasCostEth,
    };
  } catch (e) {
    return { gasLimit: '200000', gasPrice: '--', gasCostEth: '--' };
  }
}

// Alchemy API: Busca histórico de transações
async function fetchTransactionHistory(address, chainId) {
  const { settings } = window.AppState;
  if (!settings.alchemyApiKey) return null;
  const net = NETWORKS[chainId];
  if (!net || !net.alchemyPrefix) return null;
  const url = `https://${net.alchemyPrefix}.g.alchemy.com/v2/${settings.alchemyApiKey}`;
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0', id: 1, method: 'alchemy_getAssetTransfers',
        params: [{
          fromAddress: address,
          category: ['external', 'erc20', 'erc721'],
          maxCount: '0x14',
          order: 'desc',
          withMetadata: true,
        }],
      }),
    });
    const data = await res.json();
    return data.result?.transfers || [];
  } catch (e) {
    console.error('fetchTransactionHistory error:', e);
    return null;
  }
}
