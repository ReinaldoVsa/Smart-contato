// ===== CONFIG.JS - Configurações e constantes =====

const NETWORKS = {
  1:     { name: 'Ethereum Mainnet', symbol: 'ETH',   rpc: 'eth-mainnet',      explorer: 'https://etherscan.io',         alchemyPrefix: 'eth-mainnet'    },
  137:   { name: 'Polygon',          symbol: 'MATIC',  rpc: 'polygon-mainnet',  explorer: 'https://polygonscan.com',      alchemyPrefix: 'polygon-mainnet' },
  56:    { name: 'BNB Chain',        symbol: 'BNB',   rpc: null,               explorer: 'https://bscscan.com',          publicRpc: 'https://bsc-dataseed.binance.org' },
  42161: { name: 'Arbitrum One',     symbol: 'ETH',   rpc: 'arb-mainnet',      explorer: 'https://arbiscan.io',          alchemyPrefix: 'arb-mainnet'    },
  10:    { name: 'Optimism',         symbol: 'ETH',   rpc: 'opt-mainnet',      explorer: 'https://optimistic.etherscan.io', alchemyPrefix: 'opt-mainnet' },
  8453:  { name: 'Base',             symbol: 'ETH',   rpc: 'base-mainnet',     explorer: 'https://basescan.org',         alchemyPrefix: 'base-mainnet'   },
  43114: { name: 'Avalanche',        symbol: 'AVAX',  rpc: null,               explorer: 'https://snowtrace.io',         publicRpc: 'https://api.avax.network/ext/bc/C/rpc' },
};

const ERC20_ABI = [
  'function name() view returns (string)',
  'function symbol() view returns (string)',
  'function decimals() view returns (uint8)',
  'function totalSupply() view returns (uint256)',
  'function balanceOf(address) view returns (uint256)',
  'function transfer(address to, uint256 amount) returns (bool)',
  'function allowance(address owner, address spender) view returns (uint256)',
  'function approve(address spender, uint256 amount) returns (bool)',
  'function transferFrom(address from, address to, uint256 amount) returns (bool)',
  'event Transfer(address indexed from, address indexed to, uint256 value)',
  'event Approval(address indexed owner, address indexed spender, uint256 value)',
];

const ERC721_ABI = [
  'function name() view returns (string)',
  'function symbol() view returns (string)',
  'function ownerOf(uint256 tokenId) view returns (address)',
  'function balanceOf(address owner) view returns (uint256)',
  'function transferFrom(address from, address to, uint256 tokenId)',
  'function safeTransferFrom(address from, address to, uint256 tokenId)',
  'function approve(address to, uint256 tokenId)',
  'function getApproved(uint256 tokenId) view returns (address)',
  'function isApprovedForAll(address owner, address operator) view returns (bool)',
  'function setApprovalForAll(address operator, bool approved)',
];

// Uniswap V2 Router (present on most EVM networks)
const UNISWAP_V2_ROUTER = {
  1:     '0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D', // Ethereum
  137:   '0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff', // QuickSwap Polygon
  56:    '0x10ED43C718714eb63d5aA57B78B54704E256024E', // PancakeSwap BNB
  42161: '0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506', // SushiSwap Arbitrum
  10:    '0x4A7b5Da61326A6379179b40d00F57E5bbDC962c2', // Velodrome Optimism
  8453:  '0x8cFe327CEc66d1C090Dd72bd0FF11d690C33a2Eb', // BaseSwap Base
};

// Uniswap V2 Router ABI (apenas funções necessárias)
const ROUTER_ABI = [
  'function getAmountsOut(uint amountIn, address[] calldata path) view returns (uint[] memory amounts)',
  'function swapExactETHForTokens(uint amountOutMin, address[] calldata path, address to, uint deadline) payable returns (uint[] memory amounts)',
  'function swapExactTokensForETH(uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline) returns (uint[] memory amounts)',
  'function swapExactTokensForTokens(uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline) returns (uint[] memory amounts)',
  'function WETH() view returns (address)',
];

const WETH_ADDRESSES = {
  1:     '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
  137:   '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270', // WMATIC
  56:    '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c', // WBNB
  42161: '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1',
  10:    '0x4200000000000000000000000000000000000006',
  8453:  '0x4200000000000000000000000000000000000006',
  43114: '0xB31f66AA3C1e785363F0875A1B74E27b85FD66c7', // WAVAX
};

// LocalStorage keys
const STORAGE_KEYS = {
  SETTINGS: 'smartwallet_settings',
  HISTORY:  'smartwallet_history',
  WALLET:   'smartwallet_wallet',
};

const DEFAULT_SETTINGS = {
  alchemyApiKey: '',
  walletConnectProjectId: '',
  defaultNetwork: 1,
  customRpc: '',
  gasPriceMultiplier: 1.2,
  confirmToggle: true,
  historyToggle: true,
};

// Carrega ou retorna padrão
function loadSettings() {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : { ...DEFAULT_SETTINGS };
  } catch { return { ...DEFAULT_SETTINGS }; }
}

function saveSettings(settings) {
  try { localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings)); return true; }
  catch { return false; }
}

function loadHistory() {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.HISTORY);
    return saved ? JSON.parse(saved) : [];
  } catch { return []; }
}

function saveHistory(history) {
  try { localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(history.slice(0, 100))); }
  catch { console.warn('Could not save history'); }
}

function loadWalletState() {
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.WALLET);
    return saved ? JSON.parse(saved) : null;
  } catch { return null; }
}

function saveWalletState(state) {
  try { localStorage.setItem(STORAGE_KEYS.WALLET, JSON.stringify(state)); }
  catch {}
}

function clearAllData() {
  Object.values(STORAGE_KEYS).forEach(k => localStorage.removeItem(k));
}

// Estado global
window.AppState = {
  settings: loadSettings(),
  provider: null,
  signer: null,
  walletAddress: null,
  chainId: null,
  network: null,
  connected: false,
  walletConnectInstance: null,
  currentContract: null,
  currentTokenInfo: null,
  pendingTxConfirm: null,
  history: loadHistory(),
  swapQuote: null,
};
