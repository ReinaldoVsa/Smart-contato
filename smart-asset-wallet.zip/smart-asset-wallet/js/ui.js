// ===== UI.JS - Helpers de Interface =====

let toastTimeout;

function showToast(msg, type = 'info') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = `toast show ${type}`;
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => { el.classList.remove('show'); }, 3500);
}

function showScreen(screenId) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const target = document.getElementById(screenId);
  if (target) target.classList.add('active');

  // Atualiza nav bar
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.screen === screenId);
  });

  // Se é dashboard, atualiza listas
  if (screenId === 'dashboardScreen') {
    renderDashboardTxList();
  }
}

function setLoading(btn, loading) {
  if (loading) {
    btn.classList.add('btn-loading');
    btn.disabled = true;
    btn._originalText = btn.innerHTML;
  } else {
    btn.classList.remove('btn-loading');
    btn.disabled = false;
    if (btn._originalText) btn.innerHTML = btn._originalText;
  }
}

function initTabs() {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      const targetId = tab.dataset.tab;
      const parent = tab.closest('[class*="form-card"], [class*="section-card"]') || tab.parentElement.parentElement;
      parent.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      parent.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      tab.classList.add('active');
      const content = document.getElementById(targetId);
      if (content) content.classList.add('active');
    });
  });
}

function initEyeBtns() {
  document.querySelectorAll('.eye-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const input = document.getElementById(btn.dataset.target);
      if (input) {
        input.type = input.type === 'password' ? 'text' : 'password';
        btn.textContent = input.type === 'password' ? '👁' : '🙈';
      }
    });
  });
}

function formatAddress(addr) {
  if (!addr) return '';
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
}

function validateAddress(addr) {
  return ethers.utils.isAddress(addr);
}

function fillSettingsUI() {
  const s = window.AppState.settings;
  const setVal = (id, val) => { const el = document.getElementById(id); if (el) el.value = val || ''; };
  setVal('alchemyApiKey', s.alchemyApiKey);
  setVal('walletConnectProjectId', s.walletConnectProjectId);
  setVal('defaultNetwork', s.defaultNetwork || 1);
  setVal('customRpc', s.customRpc);
  setVal('gasPriceMultiplier', s.gasPriceMultiplier);
  const ct = document.getElementById('confirmToggle');
  const ht = document.getElementById('historyToggle');
  if (ct) ct.checked = !!s.confirmToggle;
  if (ht) ht.checked = !!s.historyToggle;
}

function collectSettingsUI() {
  const getVal = id => { const el = document.getElementById(id); return el ? el.value.trim() : ''; };
  return {
    alchemyApiKey: getVal('alchemyApiKey'),
    walletConnectProjectId: getVal('walletConnectProjectId'),
    defaultNetwork: parseInt(getVal('defaultNetwork')) || 1,
    customRpc: getVal('customRpc'),
    gasPriceMultiplier: parseFloat(getVal('gasPriceMultiplier')) || 1.2,
    confirmToggle: document.getElementById('confirmToggle')?.checked ?? true,
    historyToggle: document.getElementById('historyToggle')?.checked ?? true,
  };
}
