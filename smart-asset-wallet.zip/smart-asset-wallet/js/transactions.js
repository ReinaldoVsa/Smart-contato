// ===== TRANSACTIONS.JS - Saque, Transferência e Histórico =====

// ----- SAQUE NATIVO -----
async function withdrawNative(to, amount) {
  if (!ethers.utils.isAddress(to)) throw new Error('Endereço destino inválido');
  const signer = await requireSigner();
  const { provider, settings } = window.AppState;
  const amountWei = ethers.utils.parseEther(amount.toString());

  // Estima gas
  const gasPrice = await provider.getGasPrice();
  const multiplier = Math.floor(parseFloat(settings.gasPriceMultiplier) * 100);
  const adjustedGasPrice = gasPrice.mul(multiplier).div(100);

  const txParams = { to, value: amountWei, gasPrice: adjustedGasPrice };
  const gasLimit = await provider.estimateGas(txParams).catch(() => ethers.BigNumber.from(21000));

  showToast('Enviando transação...', 'info');
  const tx = await signer.sendTransaction({ ...txParams, gasLimit });
  addToHistory({ type: 'Saque Nativo', to, amount, symbol: window.AppState.network.symbol, hash: tx.hash, status: 'pending' });
  showPendingModal(tx.hash);
  tx.wait().then(() => { updateHistoryStatus(tx.hash, 'confirmed'); showToast('Saque confirmado!', 'success'); });
  return tx;
}

// ----- SAQUE TOKEN ERC20 -----
async function withdrawToken(tokenAddress, to, amount) {
  if (!ethers.utils.isAddress(to)) throw new Error('Endereço destino inválido');
  if (!ethers.utils.isAddress(tokenAddress)) throw new Error('Contrato do token inválido');

  const signer = await requireSigner();
  const { walletAddress, provider } = window.AppState;

  const info = await fetchTokenInfo(tokenAddress, walletAddress, provider);
  const amountWei = ethers.utils.parseUnits(amount.toString(), info.decimals);

  const token = new ethers.Contract(tokenAddress, ERC20_ABI, signer);
  showToast('Enviando token...', 'info');
  const tx = await token.transfer(to, amountWei);
  addToHistory({ type: `Saque ${info.symbol}`, to, amount, symbol: info.symbol, hash: tx.hash, status: 'pending' });
  showPendingModal(tx.hash);
  tx.wait().then(() => { updateHistoryStatus(tx.hash, 'confirmed'); showToast(`${info.symbol} enviado!`, 'success'); });
  return tx;
}

// ----- SAQUE VIA CONTRATO -----
async function withdrawViaContract(contractAddr, funcName, abiJson, params) {
  if (!ethers.utils.isAddress(contractAddr)) throw new Error('Endereço do contrato inválido');

  showToast('Executando função do contrato...', 'info');
  let parsedParams = [];
  if (params && params.trim()) {
    parsedParams = params.split(',').map(p => {
      const t = p.trim();
      if (/^\d+$/.test(t)) return ethers.BigNumber.from(t);
      if (t.startsWith('0x') && ethers.utils.isAddress(t)) return t;
      return t;
    });
  }

  const tx = await executeContractFunction(contractAddr, abiJson, funcName, parsedParams);
  addToHistory({ type: `Contrato: ${funcName}`, to: contractAddr, amount: '--', symbol: '', hash: tx.hash, status: 'pending' });
  showPendingModal(tx.hash);
  tx.wait().then(() => { updateHistoryStatus(tx.hash, 'confirmed'); showToast('Função executada com sucesso!', 'success'); });
  return tx;
}

// ----- TRANSFERÊNCIA NATIVA -----
async function transferNative(to, amount) {
  return withdrawNative(to, amount); // mesma lógica
}

// ----- TRANSFERÊNCIA ERC20 -----
async function transferERC20(tokenAddress, to, amount) {
  return withdrawToken(tokenAddress, to, amount);
}

// ----- TRANSFERÊNCIA NFT ERC721 -----
async function transferNFT(nftAddress, to, tokenId) {
  if (!ethers.utils.isAddress(nftAddress)) throw new Error('Endereço do NFT inválido');
  if (!ethers.utils.isAddress(to)) throw new Error('Endereço destino inválido');

  const signer = await requireSigner();
  const { walletAddress } = window.AppState;
  const nft = new ethers.Contract(nftAddress, ERC721_ABI, signer);

  showToast('Transferindo NFT...', 'info');
  const tx = await nft['safeTransferFrom(address,address,uint256)'](walletAddress, to, tokenId);
  addToHistory({ type: 'NFT Transfer', to, amount: `#${tokenId}`, symbol: 'NFT', hash: tx.hash, status: 'pending' });
  showPendingModal(tx.hash);
  tx.wait().then(() => { updateHistoryStatus(tx.hash, 'confirmed'); showToast('NFT transferido!', 'success'); });
  return tx;
}

// ----- HISTÓRICO -----
function addToHistory(entry) {
  const { settings } = window.AppState;
  if (!settings.historyToggle) return;
  const item = {
    ...entry,
    id: Date.now(),
    timestamp: new Date().toISOString(),
    chainId: window.AppState.chainId,
  };
  window.AppState.history.unshift(item);
  saveHistory(window.AppState.history);
  renderHistory();
  renderDashboardTxList();
}

function updateHistoryStatus(hash, status) {
  const item = window.AppState.history.find(h => h.hash === hash);
  if (item) {
    item.status = status;
    saveHistory(window.AppState.history);
    renderHistory();
    renderDashboardTxList();
  }
}

function loadHistoryFromStorage() {
  window.AppState.history = loadHistory();
  renderHistory();
  renderDashboardTxList();
}

function renderDashboardTxList() {
  const container = document.getElementById('txList');
  const history = window.AppState.history.slice(0, 5);
  if (!history.length) {
    container.innerHTML = '<div class="empty-state">Nenhuma transação ainda</div>';
    return;
  }
  container.innerHTML = history.map(tx => buildTxItem(tx)).join('');
}

function renderHistory(filter = 'all') {
  const container = document.getElementById('historyList');
  let history = window.AppState.history;
  if (filter !== 'all') {
    history = history.filter(tx => {
      if (filter === 'send') return tx.type.includes('Saque') || tx.type.includes('Transfer');
      if (filter === 'receive') return tx.type.includes('Recebimento');
      if (filter === 'swap') return tx.type.includes('Swap') || tx.type.includes('Troca');
      return true;
    });
  }
  if (!history.length) {
    container.innerHTML = '<div class="empty-state">Nenhuma transação no histórico</div>';
    return;
  }
  container.innerHTML = history.map(tx => buildTxItem(tx)).join('');
}

function buildTxItem(tx) {
  const net = NETWORKS[tx.chainId] || {};
  const explorerUrl = net.explorer ? `${net.explorer}/tx/${tx.hash}` : `#`;
  const isNeg = tx.type.includes('Saque') || tx.type.includes('Transfer') || tx.type.includes('Swap') || tx.type.includes('Contrato');
  const date = new Date(tx.timestamp);
  const timeStr = date.toLocaleDateString('pt-BR') + ' ' + date.toLocaleTimeString('pt-BR', {hour:'2-digit', minute:'2-digit'});
  return `
    <div class="tx-item" onclick="window.open('${explorerUrl}', '_blank')">
      <div class="tx-left">
        <span class="tx-type">${tx.type}</span>
        <span class="tx-time">${timeStr}</span>
      </div>
      <div class="tx-right">
        <span class="tx-amount ${isNeg ? 'negative' : 'positive'}">${isNeg ? '-' : '+'}${tx.amount} ${tx.symbol}</span>
        <span class="tx-status ${tx.status}">${tx.status === 'confirmed' ? 'Confirmado' : tx.status === 'pending' ? 'Pendente' : 'Falhou'}</span>
      </div>
    </div>
  `;
}

// ----- CONFIRMAÇÃO MODAL -----
function showConfirmModal(details, onConfirm) {
  const { settings } = window.AppState;
  if (!settings.confirmToggle) { onConfirm(); return; }
  document.getElementById('confirmDetails').innerHTML = details;
  document.getElementById('confirmModal').classList.remove('hidden');
  window.AppState.pendingTxConfirm = onConfirm;
}

function showPendingModal(hash) {
  const net = NETWORKS[window.AppState.chainId] || {};
  const explorerUrl = net.explorer ? `${net.explorer}/tx/${hash}` : '#';
  document.getElementById('pendingTxHash').innerHTML =
    `<a href="${explorerUrl}" target="_blank" rel="noopener" style="color:var(--accent);text-decoration:none">${hash}</a>`;
  document.getElementById('pendingModal').classList.remove('hidden');
}
