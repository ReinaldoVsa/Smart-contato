// ===== SWAP.JS - Troca de Tokens via DEX (Uniswap V2 compatible) =====

let currentSlippage = 0.5;
let swapQuoteData = null;

async function getSwapQuote(fromIsNative, fromAddr, toIsNative, toAddr, amountIn) {
  const { chainId, provider } = window.AppState;
  const routerAddr = UNISWAP_V2_ROUTER[chainId];

  if (!routerAddr) throw new Error(`DEX não suportada nesta rede (chain ${chainId})`);
  if (!provider) throw new Error('Provider não disponível');

  const weth = WETH_ADDRESSES[chainId];
  if (!weth) throw new Error('WETH não configurado para esta rede');

  const router = new ethers.Contract(routerAddr, ROUTER_ABI, provider);

  let fromDecimals = 18;
  let toDecimals = 18;
  let fromSymbol = window.AppState.network?.symbol || 'ETH';
  let toSymbol = '';

  let path = [];

  if (fromIsNative) {
    path.push(weth);
    fromDecimals = 18;
    fromSymbol = window.AppState.network?.symbol || 'ETH';
  } else {
    if (!ethers.utils.isAddress(fromAddr)) throw new Error('Endereço do token de origem inválido');
    const info = await fetchTokenInfo(fromAddr, window.AppState.walletAddress, provider);
    fromDecimals = info.decimals;
    fromSymbol = info.symbol;
    path.push(fromAddr);
  }

  if (toIsNative) {
    if (path[0] !== weth) path.push(weth);
    toDecimals = 18;
    toSymbol = window.AppState.network?.symbol || 'ETH';
  } else {
    if (!ethers.utils.isAddress(toAddr)) throw new Error('Endereço do token de destino inválido');
    const info = await fetchTokenInfo(toAddr, null, provider);
    toDecimals = info.decimals;
    toSymbol = info.symbol;
    // Adiciona WETH como intermediário se necessário
    if (!fromIsNative) path.push(weth);
    path.push(toAddr);
  }

  const amountInWei = ethers.utils.parseUnits(amountIn.toString(), fromDecimals);
  const amounts = await router.getAmountsOut(amountInWei, path);
  const amountOutWei = amounts[amounts.length - 1];
  const amountOut = ethers.utils.formatUnits(amountOutWei, toDecimals);

  // Calcula slippage
  const slipFactor = 1 - (currentSlippage / 100);
  const amountOutMin = amountOutWei.mul(Math.floor(slipFactor * 10000)).div(10000);

  const routeStr = path.map((a, i) => {
    if (a.toLowerCase() === weth.toLowerCase()) return fromIsNative ? fromSymbol : (toIsNative ? toSymbol : 'WETH');
    if (i === 0) return fromSymbol;
    return toSymbol;
  }).join(' → ');

  swapQuoteData = {
    fromIsNative, fromAddr, toIsNative, toAddr,
    amountIn, amountInWei, amountOut, amountOutMin, amountOutWei,
    path, fromDecimals, toDecimals, fromSymbol, toSymbol,
    routerAddr, routeStr,
  };

  return swapQuoteData;
}

async function executeSwap(recipient) {
  if (!swapQuoteData) throw new Error('Obtenha uma cotação primeiro');
  const signer = await requireSigner();
  const { walletAddress } = window.AppState;
  const to = (recipient && ethers.utils.isAddress(recipient)) ? recipient : walletAddress;
  const deadline = Math.floor(Date.now() / 1000) + 60 * 20; // 20 minutos

  const router = new ethers.Contract(swapQuoteData.routerAddr, ROUTER_ABI, signer);
  let tx;

  if (swapQuoteData.fromIsNative) {
    // ETH → Token
    tx = await router.swapExactETHForTokens(
      swapQuoteData.amountOutMin,
      swapQuoteData.path,
      to,
      deadline,
      { value: swapQuoteData.amountInWei }
    );
  } else if (swapQuoteData.toIsNative) {
    // Token → ETH
    // Primeiro: approve
    await approveToken(swapQuoteData.fromAddr, swapQuoteData.routerAddr, swapQuoteData.amountIn, swapQuoteData.fromDecimals);
    tx = await router.swapExactTokensForETH(
      swapQuoteData.amountInWei,
      swapQuoteData.amountOutMin,
      swapQuoteData.path,
      to,
      deadline
    );
  } else {
    // Token → Token
    await approveToken(swapQuoteData.fromAddr, swapQuoteData.routerAddr, swapQuoteData.amountIn, swapQuoteData.fromDecimals);
    tx = await router.swapExactTokensForTokens(
      swapQuoteData.amountInWei,
      swapQuoteData.amountOutMin,
      swapQuoteData.path,
      to,
      deadline
    );
  }

  const label = `Swap ${swapQuoteData.fromSymbol} → ${swapQuoteData.toSymbol}`;
  addToHistory({
    type: label,
    to,
    amount: `${parseFloat(swapQuoteData.amountIn).toFixed(4)} → ${parseFloat(swapQuoteData.amountOut).toFixed(4)}`,
    symbol: `${swapQuoteData.fromSymbol}/${swapQuoteData.toSymbol}`,
    hash: tx.hash,
    status: 'pending',
  });

  showPendingModal(tx.hash);
  tx.wait().then(() => {
    updateHistoryStatus(tx.hash, 'confirmed');
    showToast('Swap concluído!', 'success');
  }).catch(() => {
    updateHistoryStatus(tx.hash, 'failed');
  });

  swapQuoteData = null;
  return tx;
}
