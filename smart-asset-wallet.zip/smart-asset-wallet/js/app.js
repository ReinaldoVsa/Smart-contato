// ===== APP.JS - Inicialização e Event Handlers Principais =====

document.addEventListener('DOMContentLoaded', () => {
  // Splash screen
  setTimeout(() => {
    document.getElementById('splash').classList.add('out');
    document.getElementById('app').classList.remove('hidden');
    setTimeout(() => document.getElementById('splash').remove(), 600);
  }, 1800);

  initTabs();
  initEyeBtns();
  fillSettingsUI();
  initEventHandlers();

  // Verifica sessão anterior
  const saved = loadWalletState();
  if (saved?.address) {
    // Tenta reconectar em modo leitura silencioso
    tryAutoReconnect(saved);
  }
});

async function tryAutoReconnect(saved) {
  try {
    const chainId = saved.chainId || 1;
    const provider = createProvider(chainId);
    await onWalletConnected(saved.address, chainId, provider, null);
    showToast('Sessão restaurada (modo leitura)', 'info');
  } catch (e) {
    localStorage.removeItem(STORAGE_KEYS.WALLET);
  }
}

function initEventHandlers() {

  // ===== CONNECT SCREEN =====
  document.getElementById('walletConnectBtn').addEventListener('click', () => {
    connectWalletConnect();
  });

  document.getElementById('manualConnectBtn').addEventListener('click', () => {
    document.getElementById('manualInput').classList.toggle('hidden');
  });

  document.getElementById('connectManualBtn').addEventListener('click', async () => {
    const addr = document.getElementById('walletAddressInput').value.trim();
    const chainId = parseInt(document.getElementById('networkSelect').value);
    const contract = document.getElementById('contractInput').value.trim();
    await connectManual(addr, chainId, contract || null);
  });

  // ===== SETTINGS =====
  document.getElementById('settingsBtn').addEventListener('click', () => {
    fillSettingsUI();
    showScreen('settingsScreen');
  });

  document.getElementById('saveSettingsBtn').addEventListener('click', () => {
    const settings = collectSettingsUI();
    window.AppState.settings = settings;
    saveSettings(settings);
    showToast('Configurações salvas!', 'success');
  });

  document.getElementById('clearDataBtn').addEventListener('click', () => {
    if (confirm('Limpar todos os dados locais? (histórico, configurações, sessão)')) {
      clearAllData();
      window.location.reload();
    }
  });

  // ===== DASHBOARD =====
  document.getElementById('disconnectBtn').addEventListener('click', () => {
    if (confirm('Desconectar carteira?')) disconnectWallet();
  });

  document.getElementById('refreshBtn').addEventListener('click', async () => {
    const btn = document.getElementById('refreshBtn');
    btn.textContent = '↻ Atualizando...';
    btn.disabled = true;
    await refreshBalances();
    btn.textContent = '↻ Atualizar';
    btn.disabled = false;
    showToast('Saldos atualizados', 'success');
  });

  document.getElementById('loadContractBtn').addEventListener('click', async () => {
    const addr = document.getElementById('contractAddress').value.trim();
    const btn = document.getElementById('loadContractBtn');
    setLoading(btn, true);
    await loadContract(addr);
    setLoading(btn, false);
  });

  // Quick actions
  document.getElementById('withdrawActionBtn').addEventListener('click', () => showScreen('withdrawScreen'));
  document.getElementById('transferActionBtn').addEventListener('click', () => showScreen('transferScreen'));
  document.getElementById('swapActionBtn').addEventListener('click', () => showScreen('swapScreen'));
  document.getElementById('historyActionBtn').addEventListener('click', () => showScreen('historyScreen'));

  // Bottom nav
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.screen;
      if (!window.AppState.connected && target !== 'connectScreen') {
        showToast('Conecte sua carteira primeiro', 'warn');
        return;
      }
      showScreen(target);
    });
  });

  // Back buttons
  document.querySelectorAll('.back-btn').forEach(btn => {
    btn.addEventListener('click', () => showScreen(btn.dataset.target));
  });

  // ===== WITHDRAW =====
  // MAX buttons
  document.getElementById('maxNativeBtn').addEventListener('click', async () => {
    const bal = document.getElementById('nativeBalance').textContent;
    document.getElementById('withdrawNativeAmount').value = bal !== '--' ? Math.max(0, parseFloat(bal) - 0.001).toFixed(6) : '';
  });

  document.getElementById('maxTokenBtn').addEventListener('click', async () => {
    const info = window.AppState.currentTokenInfo;
    if (!info) { showToast('Carregue um token primeiro', 'warn'); return; }
    document.getElementById('withdrawTokenAmount').value = info.balance;
  });

  document.getElementById('loadWithdrawTokenBtn').addEventListener('click', async () => {
    const addr = document.getElementById('withdrawTokenContract').value.trim();
    const { walletAddress, provider } = window.AppState;
    if (!provider) { showToast('Conecte primeiro', 'error'); return; }
    try {
      const info = await fetchTokenInfo(addr, walletAddress, provider);
      document.getElementById('twName').textContent = info.name;
      document.getElementById('twSymbol').textContent = info.symbol;
      document.getElementById('twBalance').textContent = `${parseFloat(info.balance).toFixed(4)} ${info.symbol}`;
      document.getElementById('tokenWithdrawInfo').classList.remove('hidden');
      document.getElementById('maxTokenBtn').addEventListener('click', () => {
        document.getElementById('withdrawTokenAmount').value = info.balance;
      }, { once: true });
    } catch (e) { showToast('Erro: ' + e.message, 'error'); }
  });

  document.getElementById('withdrawNativeBtn').addEventListener('click', async () => {
    const to = document.getElementById('withdrawNativeTo').value.trim();
    const amount = document.getElementById('withdrawNativeAmount').value;
    if (!to || !amount) { showToast('Preencha todos os campos', 'warn'); return; }
    showConfirmModal(
      `Tipo: Saque Nativo<br>Para: ${to}<br>Valor: ${amount} ${window.AppState.network?.symbol || 'ETH'}`,
      async () => {
        const btn = document.getElementById('withdrawNativeBtn');
        setLoading(btn, true);
        try { await withdrawNative(to, amount); }
        catch (e) { showToast('Erro: ' + e.message, 'error'); }
        setLoading(btn, false);
      }
    );
  });

  document.getElementById('withdrawTokenBtn').addEventListener('click', async () => {
    const contract = document.getElementById('withdrawTokenContract').value.trim();
    const to = document.getElementById('withdrawTokenTo').value.trim();
    const amount = document.getElementById('withdrawTokenAmount').value;
    if (!contract || !to || !amount) { showToast('Preencha todos os campos', 'warn'); return; }
    showConfirmModal(
      `Tipo: Saque Token<br>Contrato: ${formatAddress(contract)}<br>Para: ${formatAddress(to)}<br>Valor: ${amount}`,
      async () => {
        const btn = document.getElementById('withdrawTokenBtn');
        setLoading(btn, true);
        try { await withdrawToken(contract, to, amount); }
        catch (e) { showToast('Erro: ' + e.message, 'error'); }
        setLoading(btn, false);
      }
    );
  });

  document.getElementById('withdrawContractBtn').addEventListener('click', async () => {
    const addr = document.getElementById('withdrawContractAddr').value.trim();
    const func = document.getElementById('withdrawFunctionName').value.trim();
    const abi = document.getElementById('withdrawABI').value.trim();
    const params = document.getElementById('withdrawParams').value.trim();
    if (!addr || !func || !abi) { showToast('Preencha contrato, função e ABI', 'warn'); return; }
    showConfirmModal(
      `Tipo: Chamada de Contrato<br>Contrato: ${formatAddress(addr)}<br>Função: ${func}<br>Params: ${params || 'nenhum'}`,
      async () => {
        const btn = document.getElementById('withdrawContractBtn');
        setLoading(btn, true);
        try { await withdrawViaContract(addr, func, abi, params); }
        catch (e) { showToast('Erro: ' + e.message, 'error'); }
        setLoading(btn, false);
      }
    );
  });

  // ===== TRANSFER =====
  document.getElementById('maxTransferEthBtn').addEventListener('click', () => {
    const bal = document.getElementById('nativeBalance').textContent;
    document.getElementById('transferEthAmount').value = bal !== '--' ? Math.max(0, parseFloat(bal) - 0.001).toFixed(6) : '';
  });

  document.getElementById('loadTransferTokenBtn').addEventListener('click', async () => {
    const addr = document.getElementById('transferTokenAddr').value.trim();
    const { walletAddress, provider } = window.AppState;
    if (!provider) { showToast('Conecte primeiro', 'error'); return; }
    try {
      const info = await fetchTokenInfo(addr, walletAddress, provider);
      document.getElementById('ttName').textContent = info.name;
      document.getElementById('ttBalance').textContent = `${parseFloat(info.balance).toFixed(4)} ${info.symbol}`;
      document.getElementById('transferTokenInfo').classList.remove('hidden');
      window.AppState._transferToken = info;
    } catch (e) { showToast('Erro: ' + e.message, 'error'); }
  });

  document.getElementById('maxTransferERC20Btn').addEventListener('click', () => {
    const info = window.AppState._transferToken;
    if (info) document.getElementById('transferERC20Amount').value = info.balance;
  });

  document.getElementById('transferEthBtn').addEventListener('click', async () => {
    const to = document.getElementById('transferEthTo').value.trim();
    const amount = document.getElementById('transferEthAmount').value;
    if (!to || !amount) { showToast('Preencha todos os campos', 'warn'); return; }
    showConfirmModal(
      `Tipo: Transferência Nativa<br>Para: ${to}<br>Valor: ${amount} ${window.AppState.network?.symbol || 'ETH'}`,
      async () => {
        const btn = document.getElementById('transferEthBtn');
        setLoading(btn, true);
        try { await transferNative(to, amount); }
        catch (e) { showToast('Erro: ' + e.message, 'error'); }
        setLoading(btn, false);
      }
    );
  });

  document.getElementById('transferERC20Btn').addEventListener('click', async () => {
    const tokenAddr = document.getElementById('transferTokenAddr').value.trim();
    const to = document.getElementById('transferERC20To').value.trim();
    const amount = document.getElementById('transferERC20Amount').value;
    if (!tokenAddr || !to || !amount) { showToast('Preencha todos os campos', 'warn'); return; }
    showConfirmModal(
      `Tipo: Transferência ERC-20<br>Token: ${formatAddress(tokenAddr)}<br>Para: ${formatAddress(to)}<br>Valor: ${amount}`,
      async () => {
        const btn = document.getElementById('transferERC20Btn');
        setLoading(btn, true);
        try { await transferERC20(tokenAddr, to, amount); }
        catch (e) { showToast('Erro: ' + e.message, 'error'); }
        setLoading(btn, false);
      }
    );
  });

  document.getElementById('transferNFTBtn').addEventListener('click', async () => {
    const nftAddr = document.getElementById('transferNFTAddr').value.trim();
    const to = document.getElementById('transferNFTTo').value.trim();
    const tokenId = document.getElementById('transferNFTId').value;
    if (!nftAddr || !to || !tokenId) { showToast('Preencha todos os campos', 'warn'); return; }
    showConfirmModal(
      `Tipo: Transferência NFT<br>Contrato: ${formatAddress(nftAddr)}<br>Token ID: ${tokenId}<br>Para: ${formatAddress(to)}`,
      async () => {
        const btn = document.getElementById('transferNFTBtn');
        setLoading(btn, true);
        try { await transferNFT(nftAddr, to, parseInt(tokenId)); }
        catch (e) { showToast('Erro: ' + e.message, 'error'); }
        setLoading(btn, false);
      }
    );
  });

  // ===== SWAP =====
  document.getElementById('swapFromToken').addEventListener('change', (e) => {
    document.getElementById('swapFromCustom').classList.toggle('hidden', e.target.value !== 'custom');
    swapQuoteData = null;
    document.getElementById('executeSwapBtn').classList.add('hidden');
    document.getElementById('getQuoteBtn').classList.remove('hidden');
  });

  document.getElementById('swapToToken').addEventListener('change', (e) => {
    document.getElementById('swapToCustom').classList.toggle('hidden', e.target.value !== 'custom');
    swapQuoteData = null;
    document.getElementById('executeSwapBtn').classList.add('hidden');
    document.getElementById('getQuoteBtn').classList.remove('hidden');
  });

  document.querySelectorAll('.slip-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.slip-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentSlippage = parseFloat(btn.dataset.slip);
      document.getElementById('customSlippage').value = '';
    });
  });

  document.getElementById('customSlippage').addEventListener('input', (e) => {
    const val = parseFloat(e.target.value);
    if (val > 0) {
      currentSlippage = val;
      document.querySelectorAll('.slip-btn').forEach(b => b.classList.remove('active'));
    }
  });

  document.getElementById('swapDirectionBtn').addEventListener('click', () => {
    const fromSel = document.getElementById('swapFromToken');
    const toSel = document.getElementById('swapToToken');
    const fromVal = fromSel.value, toVal = toSel.value;
    fromSel.value = toVal; toSel.value = fromVal;
    const fromCustom = document.getElementById('swapFromCustom');
    const toCustom = document.getElementById('swapToCustom');
    const fromAddr = document.getElementById('swapFromAddr').value;
    const toAddr = document.getElementById('swapToAddr').value;
    document.getElementById('swapFromAddr').value = toAddr;
    document.getElementById('swapToAddr').value = fromAddr;
    fromCustom.classList.toggle('hidden', fromSel.value !== 'custom');
    toCustom.classList.toggle('hidden', toSel.value !== 'custom');
    swapQuoteData = null;
    document.getElementById('executeSwapBtn').classList.add('hidden');
    document.getElementById('getQuoteBtn').classList.remove('hidden');
    document.getElementById('swapRoute').textContent = '';
  });

  document.getElementById('maxSwapFromBtn').addEventListener('click', async () => {
    const fromSel = document.getElementById('swapFromToken').value;
    if (fromSel === 'native') {
      document.getElementById('swapFromAmount').value = Math.max(0, parseFloat(document.getElementById('nativeBalance').textContent || 0) - 0.001).toFixed(6);
    } else {
      const addr = document.getElementById('swapFromAddr').value.trim();
      if (addr && window.AppState.provider) {
        const info = await fetchTokenInfo(addr, window.AppState.walletAddress, window.AppState.provider).catch(() => null);
        if (info) document.getElementById('swapFromAmount').value = info.balance;
      }
    }
  });

  document.getElementById('getQuoteBtn').addEventListener('click', async () => {
    const fromSel = document.getElementById('swapFromToken').value;
    const toSel = document.getElementById('swapToToken').value;
    const fromIsNative = fromSel === 'native';
    const toIsNative = toSel === 'native';
    const fromAddr = document.getElementById('swapFromAddr').value.trim();
    const toAddr = document.getElementById('swapToAddr').value.trim();
    const amountIn = document.getElementById('swapFromAmount').value;

    if (!amountIn || parseFloat(amountIn) <= 0) { showToast('Insira o valor', 'warn'); return; }
    if (!window.AppState.provider) { showToast('Conecte sua carteira', 'error'); return; }
    if (!fromIsNative && !fromAddr) { showToast('Informe o contrato do token de origem', 'warn'); return; }
    if (!toIsNative && !toAddr) { showToast('Informe o contrato do token de destino', 'warn'); return; }

    const btn = document.getElementById('getQuoteBtn');
    setLoading(btn, true);
    try {
      const quote = await getSwapQuote(fromIsNative, fromAddr, toIsNative, toAddr, amountIn);
      document.getElementById('swapToAmount').value = parseFloat(quote.amountOut).toFixed(6);
      document.getElementById('swapRoute').textContent = `Rota: ${quote.routeStr} | Slippage: ${currentSlippage}% | Min recebido: ${parseFloat(ethers.utils.formatUnits(quote.amountOutMin, quote.toDecimals)).toFixed(6)} ${quote.toSymbol}`;
      document.getElementById('executeSwapBtn').classList.remove('hidden');
      document.getElementById('getQuoteBtn').classList.add('hidden');
      showToast('Cotação obtida!', 'success');
    } catch (e) {
      showToast('Erro ao obter cotação: ' + e.message, 'error');
    }
    setLoading(btn, false);
  });

  document.getElementById('executeSwapBtn').addEventListener('click', async () => {
    const recipient = document.getElementById('swapRecipient').value.trim();
    showConfirmModal(
      `Tipo: Swap<br>De: ${swapQuoteData?.fromSymbol}<br>Para: ${swapQuoteData?.toSymbol}<br>Valor: ${swapQuoteData?.amountIn}<br>Slippage: ${currentSlippage}%`,
      async () => {
        const btn = document.getElementById('executeSwapBtn');
        setLoading(btn, true);
        try { await executeSwap(recipient || null); }
        catch (e) { showToast('Erro no swap: ' + e.message, 'error'); }
        setLoading(btn, false);
        btn.classList.add('hidden');
        document.getElementById('getQuoteBtn').classList.remove('hidden');
      }
    );
  });

  // ===== HISTORY =====
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderHistory(btn.dataset.filter);
    });
  });

  // ===== MODAL CONFIRM =====
  document.getElementById('cancelConfirm').addEventListener('click', () => {
    document.getElementById('confirmModal').classList.add('hidden');
    window.AppState.pendingTxConfirm = null;
  });

  document.getElementById('approveConfirm').addEventListener('click', async () => {
    document.getElementById('confirmModal').classList.add('hidden');
    const cb = window.AppState.pendingTxConfirm;
    window.AppState.pendingTxConfirm = null;
    if (cb) await cb();
  });

  document.getElementById('closePending').addEventListener('click', () => {
    document.getElementById('pendingModal').classList.add('hidden');
  });
}

// ===== SERVICE WORKER =====
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js')
      .then(() => console.log('SW registered'))
      .catch(e => console.warn('SW failed:', e));
  });
}
