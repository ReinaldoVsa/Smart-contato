// ===== CONTRACT.JS - Interação com Contratos Inteligentes =====

async function loadContract(address) {
  const { walletAddress, provider } = window.AppState;
  if (!provider) { showToast('Conecte sua carteira primeiro', 'error'); return; }
  if (!ethers.utils.isAddress(address)) { showToast('Endereço de contrato inválido', 'error'); return; }

  showToast('Carregando contrato...', 'info');

  try {
    const info = await fetchTokenInfo(address, walletAddress, provider);
    window.AppState.currentTokenInfo = info;
    window.AppState.currentContract = new ethers.Contract(address, ERC20_ABI, provider);

    // Atualiza UI
    document.getElementById('contractName').textContent = info.name;
    document.getElementById('contractSymbol').textContent = info.symbol;
    document.getElementById('contractDecimals').textContent = info.decimals;
    document.getElementById('contractBalance').textContent = `${parseFloat(info.balance).toFixed(6)} ${info.symbol}`;
    document.getElementById('contractInfo').classList.remove('hidden');

    // Atualiza saldo no card
    document.getElementById('tokenBalance').textContent = parseFloat(info.balance).toFixed(4);
    document.getElementById('tokenSymbol').textContent = info.symbol;

    showToast(`${info.name} (${info.symbol}) carregado!`, 'success');
  } catch (e) {
    console.error('loadContract error:', e);
    showToast('Erro ao carregar contrato: ' + e.message, 'error');
  }
}

async function getContractWithSigner(address, abi) {
  const signer = await requireSigner();
  return new ethers.Contract(address, abi, signer);
}

async function executeContractFunction(contractAddr, abiJson, funcName, params) {
  const signer = await requireSigner();
  let abi;
  try {
    abi = typeof abiJson === 'string' ? JSON.parse(abiJson) : abiJson;
  } catch {
    throw new Error('ABI JSON inválido');
  }
  const contract = new ethers.Contract(contractAddr, abi, signer);
  if (!contract[funcName]) throw new Error(`Função '${funcName}' não encontrada no ABI`);
  const tx = await contract[funcName](...params);
  return tx;
}

async function approveToken(tokenAddress, spenderAddress, amount, decimals) {
  const signer = await requireSigner();
  const token = new ethers.Contract(tokenAddress, ERC20_ABI, signer);
  const amountWei = ethers.utils.parseUnits(amount.toString(), decimals);
  showToast('Aprovando token...', 'info');
  const tx = await token.approve(spenderAddress, amountWei);
  showToast('Aguardando aprovação...', 'info');
  await tx.wait();
  showToast('Token aprovado!', 'success');
  return tx;
}

async function checkAllowance(tokenAddress, ownerAddress, spenderAddress, provider) {
  const token = new ethers.Contract(tokenAddress, ERC20_ABI, provider);
  const [allowance, decimals] = await Promise.all([
    token.allowance(ownerAddress, spenderAddress),
    token.decimals()
  ]);
  return { allowance, decimals };
}
